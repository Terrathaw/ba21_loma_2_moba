package ch.zhaw.bait17.audio_signal_processing_toolbox;

import android.content.Context;
import android.widget.MediaController;

/**
 * Created by georgrem and stockan1 on 14.02.2017.
 */

public class MusicController extends MediaController {

    public MusicController(Context c) {
        super(c);
    }

    public void hide() {
    }

}
